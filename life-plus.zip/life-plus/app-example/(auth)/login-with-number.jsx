import { View, Text } from 'react-native'
import React from 'react'

const login = () => {
  return (
    <View>
      <Text>login-with-number</Text>
    </View>
  )
}

export default login;