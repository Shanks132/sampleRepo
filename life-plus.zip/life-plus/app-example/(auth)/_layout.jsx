import { View, Text } from 'react-native'
import React from 'react'

const _layout = () => {
  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        
        <Stack.Screen name="login-with-number"/>
      </Stack>
    </ThemeProvider>
  )
}

export default _layout