import { Link } from 'expo-router';
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import WelcomeMessage from '../../components/WelcomeMessage';

function PlusLifeLogin() {
  const [mobileNo, setMobileNo] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  const handleMobileNoChange = (text) => {
    setMobileNo(text);
  };

  const handleSendOtpClick = () => {
    // Validate mobile number format (e.g., 10 digits in India)
    if (!isValidMobileNo(mobileNo)) {
      alert('Please enter a valid 10-digit mobile number.');
      return;
    }

    // Send OTP (replace with actual OTP sending logic)
    console.log('Sending OTP to:', mobileNo);
    setOtpSent(true);
  };

  const handleResetPinClick = () => {
    // Handle reset PIN logic (e.g., navigate to a reset PIN screen)
    console.log('Reset PIN clicked');
  };

  return (
    <View style={styles.container}>
      <WelcomeMessage/>
      <TextInput
        style={styles.input}
        placeholder="Mobile no"
        value={mobileNo}
        onChangeText={handleMobileNoChange}
        keyboardType="phone-pad"
      />
      <Link href={"/home"}>Go To Home Page</Link> 
      
      <TouchableOpacity
        style={styles.button}
        onPress={handleSendOtpClick}
        disabled={!mobileNo}
      >
        
        <Text style={styles.buttonText}>Send OTP</Text>
      </TouchableOpacity>
      {otpSent && <Text style={styles.message}>OTP sent to {mobileNo}</Text>}
      <Text style={styles.link}>Already User? <Text onPress={handleResetPinClick}>Reset PIN</Text></Text>
    </View>
  );
}

function isValidMobileNo(mobileNo) {return mobileNo.length === 10 && /^[0-9]+$/.test(mobileNo);}

const styles = {
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {

    width:300,
    height: 60,
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 20,
    fontSize:22,
  },
  button: {
    flex:0.1,
    width:100,
    alignItems: 'center',
    justifyContent: 'center',
    height:0,
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize:15,
    
  },
  message: {
    marginTop: 10,
    textAlign: 'center',
  },
  link: {
    marginTop: 20,
    textAlign: 'center',
  },
};

export default PlusLifeLogin;