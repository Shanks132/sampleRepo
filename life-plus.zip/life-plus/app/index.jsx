
import { Text, View } from "react-native";
import { Link, router } from "expo-router";
import { TouchableOpacity } from "react-native";
export default function Index() {
  return (<>
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
      >
      
      <Text>Edit app/index.tsx to edit this screen.</Text>

      <TouchableOpacity onPress={()=>{router.push("/sign-in")}}>
        <Text>Click to go to Sign-in</Text>
      </TouchableOpacity>
      
      <TouchableOpacity onPress={()=>{router.push("/sign-up")}}>
        <Text>Click to go to Sign-up</Text>
      </TouchableOpacity>
        
      </View>
      </>
  );
}
