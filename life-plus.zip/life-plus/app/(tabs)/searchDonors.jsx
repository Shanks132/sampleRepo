import { View, Text } from 'react-native'
import React from 'react'

const SearchDonors = () => {
  return (
    <View>
      <Text>SearchDonors</Text>
    </View>
  )
}

export default SearchDonors