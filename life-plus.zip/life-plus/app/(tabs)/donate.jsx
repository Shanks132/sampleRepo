import { View, Text } from 'react-native'
import React from 'react'

const Donate = () => {
  return (
    <View>
      <Text>Donate</Text>
    </View>
  )
}

export default Donate